﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace PTesteEventos
{
    public partial class lblSalario : Form
    {
        public lblSalario()
        {
            InitializeComponent();
        }

        private void txtnome_KeyPress(object sender, KeyPressEventArgs e)
        {
            Char[] Numeros = { '0', '1', '2', '3', '4', '5', '6', '7', '8', '9' };

            bool temNumero = Numeros.Contains(e.KeyChar);

            if (temNumero)
            {
                MessageBox.Show("nome "+ "\" " + "não pode ter números");
                SendKeys.Send("{BACKSPACE}");
            }
        }

        private void txtEndereco_Validating(object sender, CancelEventArgs e)
        {
            if (txtEndereco.Text=="")
            {
                MessageBox.Show("Endereço inválido!");
                e.Cancel = true;
            }
        }

        private void txtEmail_Validated(object sender, EventArgs e)
        {
            if (txtEmail.Text == "")
            {
                MessageBox.Show("E-mail inválido!");
                txtEmail.Focus();
            }
        }

        private void txtCelular_KeyPress(object sender, KeyPressEventArgs e)
        {
            if (e.KeyChar == (char)13)
            {
                SendKeys.Send("{TAB}");
                e.Handled = true; // Desative o beep
            }
        }

        private void mskbxData_Validated(object sender, EventArgs e)
        {
            DateTime dtNasc;

            if (!DateTime.TryParse(mskbxData.Text, out dtNasc))
            {
                MessageBox.Show("Data de nascimento inválida!");
                mskbxData.Focus();
            }
            else
            {
                MessageBox.Show("A data é: " + dtNasc.ToShortDateString());
            }
        }

        private void mskbxSalario_Validated(object sender, EventArgs e)
        {
            double salario;

            if (!double.TryParse(mskbxSalario.Text, out salario))
            {
                MessageBox.Show("Salário inválido!");
                mskbxSalario.Focus();
            }
            else
            {
                MessageBox.Show("O salário é: " + salario.ToString("C"));
            }
        }

        private void mskbxVale_Leave(object sender, EventArgs e)
        {
            MessageBox.Show("Vale está perdendo o foco");
        }

        private void mskbxSalario_Enter(object sender, EventArgs e)
        {
            MessageBox.Show("Salário está ganhando foco");
        }
    }
}
