﻿namespace PTesteEventos
{
    partial class lblSalario
    {
        /// <summary>
        /// Variável de designer necessária.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Limpar os recursos que estão sendo usados.
        /// </summary>
        /// <param name="disposing">true se for necessário descartar os recursos gerenciados; caso contrário, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Código gerado pelo Windows Form Designer

        /// <summary>
        /// Método necessário para suporte ao Designer - não modifique 
        /// o conteúdo deste método com o editor de código.
        /// </summary>
        private void InitializeComponent()
        {
            this.lblnome = new System.Windows.Forms.Label();
            this.txtnome = new System.Windows.Forms.TextBox();
            this.txtEndereco = new System.Windows.Forms.TextBox();
            this.lblendereco = new System.Windows.Forms.Label();
            this.txtCelular = new System.Windows.Forms.TextBox();
            this.lblcelular = new System.Windows.Forms.Label();
            this.txtEmail = new System.Windows.Forms.TextBox();
            this.lblemail = new System.Windows.Forms.Label();
            this.label5 = new System.Windows.Forms.Label();
            this.lblData = new System.Windows.Forms.Label();
            this.lblvale = new System.Windows.Forms.Label();
            this.btnEnviar = new System.Windows.Forms.Button();
            this.mskbxData = new System.Windows.Forms.MaskedTextBox();
            this.mskbxVale = new System.Windows.Forms.MaskedTextBox();
            this.mskbxSalario = new System.Windows.Forms.MaskedTextBox();
            this.SuspendLayout();
            // 
            // lblnome
            // 
            this.lblnome.AutoSize = true;
            this.lblnome.Location = new System.Drawing.Point(112, 49);
            this.lblnome.Name = "lblnome";
            this.lblnome.Size = new System.Drawing.Size(51, 20);
            this.lblnome.TabIndex = 0;
            this.lblnome.Text = "Nome";
            // 
            // txtnome
            // 
            this.txtnome.Location = new System.Drawing.Point(193, 49);
            this.txtnome.Name = "txtnome";
            this.txtnome.Size = new System.Drawing.Size(312, 26);
            this.txtnome.TabIndex = 1;
            this.txtnome.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.txtnome_KeyPress);
            // 
            // txtEndereco
            // 
            this.txtEndereco.Location = new System.Drawing.Point(193, 110);
            this.txtEndereco.Name = "txtEndereco";
            this.txtEndereco.Size = new System.Drawing.Size(312, 26);
            this.txtEndereco.TabIndex = 2;
            this.txtEndereco.Validating += new System.ComponentModel.CancelEventHandler(this.txtEndereco_Validating);
            // 
            // lblendereco
            // 
            this.lblendereco.AutoSize = true;
            this.lblendereco.Location = new System.Drawing.Point(112, 110);
            this.lblendereco.Name = "lblendereco";
            this.lblendereco.Size = new System.Drawing.Size(78, 20);
            this.lblendereco.TabIndex = 2;
            this.lblendereco.Text = "Endereço";
            // 
            // txtCelular
            // 
            this.txtCelular.Location = new System.Drawing.Point(193, 237);
            this.txtCelular.Name = "txtCelular";
            this.txtCelular.Size = new System.Drawing.Size(312, 26);
            this.txtCelular.TabIndex = 4;
            this.txtCelular.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.txtCelular_KeyPress);
            // 
            // lblcelular
            // 
            this.lblcelular.AutoSize = true;
            this.lblcelular.Location = new System.Drawing.Point(112, 237);
            this.lblcelular.Name = "lblcelular";
            this.lblcelular.Size = new System.Drawing.Size(58, 20);
            this.lblcelular.TabIndex = 6;
            this.lblcelular.Text = "Celular";
            // 
            // txtEmail
            // 
            this.txtEmail.Location = new System.Drawing.Point(193, 176);
            this.txtEmail.Name = "txtEmail";
            this.txtEmail.Size = new System.Drawing.Size(312, 26);
            this.txtEmail.TabIndex = 3;
            this.txtEmail.Validated += new System.EventHandler(this.txtEmail_Validated);
            // 
            // lblemail
            // 
            this.lblemail.AutoSize = true;
            this.lblemail.Location = new System.Drawing.Point(112, 176);
            this.lblemail.Name = "lblemail";
            this.lblemail.Size = new System.Drawing.Size(53, 20);
            this.lblemail.TabIndex = 4;
            this.lblemail.Text = "E-mail";
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Location = new System.Drawing.Point(110, 449);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(58, 20);
            this.label5.TabIndex = 10;
            this.label5.Text = "Salário";
            // 
            // lblData
            // 
            this.lblData.AutoSize = true;
            this.lblData.Location = new System.Drawing.Point(110, 388);
            this.lblData.Name = "lblData";
            this.lblData.Size = new System.Drawing.Size(132, 20);
            this.lblData.TabIndex = 8;
            this.lblData.Text = "Data Nascimento";
            // 
            // lblvale
            // 
            this.lblvale.AutoSize = true;
            this.lblvale.Location = new System.Drawing.Point(575, 388);
            this.lblvale.Name = "lblvale";
            this.lblvale.Size = new System.Drawing.Size(131, 20);
            this.lblvale.TabIndex = 12;
            this.lblvale.Text = "Vale alimentação";
            // 
            // btnEnviar
            // 
            this.btnEnviar.Location = new System.Drawing.Point(579, 483);
            this.btnEnviar.Name = "btnEnviar";
            this.btnEnviar.Size = new System.Drawing.Size(424, 160);
            this.btnEnviar.TabIndex = 15;
            this.btnEnviar.Text = "Enviar Dados";
            this.btnEnviar.UseVisualStyleBackColor = true;
            // 
            // mskbxData
            // 
            this.mskbxData.Location = new System.Drawing.Point(271, 382);
            this.mskbxData.Mask = "99/99/9999";
            this.mskbxData.Name = "mskbxData";
            this.mskbxData.Size = new System.Drawing.Size(234, 26);
            this.mskbxData.TabIndex = 5;
            this.mskbxData.Validated += new System.EventHandler(this.mskbxData_Validated);
            // 
            // mskbxVale
            // 
            this.mskbxVale.Location = new System.Drawing.Point(741, 388);
            this.mskbxVale.Mask = "000.00";
            this.mskbxVale.Name = "mskbxVale";
            this.mskbxVale.Size = new System.Drawing.Size(234, 26);
            this.mskbxVale.TabIndex = 7;
            this.mskbxVale.Leave += new System.EventHandler(this.mskbxVale_Leave);
            // 
            // mskbxSalario
            // 
            this.mskbxSalario.Location = new System.Drawing.Point(271, 449);
            this.mskbxSalario.Mask = "9990.00";
            this.mskbxSalario.Name = "mskbxSalario";
            this.mskbxSalario.Size = new System.Drawing.Size(234, 26);
            this.mskbxSalario.TabIndex = 6;
            this.mskbxSalario.Enter += new System.EventHandler(this.mskbxSalario_Enter);
            this.mskbxSalario.Validated += new System.EventHandler(this.mskbxSalario_Validated);
            // 
            // lblSalario
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(9F, 20F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(1259, 655);
            this.Controls.Add(this.mskbxSalario);
            this.Controls.Add(this.mskbxVale);
            this.Controls.Add(this.mskbxData);
            this.Controls.Add(this.btnEnviar);
            this.Controls.Add(this.lblvale);
            this.Controls.Add(this.label5);
            this.Controls.Add(this.lblData);
            this.Controls.Add(this.txtCelular);
            this.Controls.Add(this.lblcelular);
            this.Controls.Add(this.txtEmail);
            this.Controls.Add(this.lblemail);
            this.Controls.Add(this.txtEndereco);
            this.Controls.Add(this.lblendereco);
            this.Controls.Add(this.txtnome);
            this.Controls.Add(this.lblnome);
            this.Name = "lblSalario";
            this.Text = "Form1";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label lblnome;
        private System.Windows.Forms.TextBox txtnome;
        private System.Windows.Forms.TextBox txtEndereco;
        private System.Windows.Forms.Label lblendereco;
        private System.Windows.Forms.TextBox txtCelular;
        private System.Windows.Forms.Label lblcelular;
        private System.Windows.Forms.TextBox txtEmail;
        private System.Windows.Forms.Label lblemail;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.Label lblData;
        private System.Windows.Forms.Label lblvale;
        private System.Windows.Forms.Button btnEnviar;
        private System.Windows.Forms.MaskedTextBox mskbxData;
        private System.Windows.Forms.MaskedTextBox mskbxVale;
        private System.Windows.Forms.MaskedTextBox mskbxSalario;
    }
}

