﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace ATIVIDADE5
{
    public partial class frmExercicio3 : Form
    {
        public frmExercicio3()
        {
            InitializeComponent();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            string input, inputNoSpace, reverse;

            if (string.IsNullOrEmpty(txtInput.Text))
            {
                MessageBox.Show("Digite algo na caixa de texto.");
            }
            else if (txtInput.Text.Length > 50)
            {
                MessageBox.Show("Texto longo demais, digite algo com menos de 50 caracteres.");
            }
            else
            {
                input = txtInput.Text;
                inputNoSpace = "";
                reverse = "";

                for (int i = 0; i < input.Length; i++)
                {
                    if (input[i] != ' ')
                        inputNoSpace += char.ToLower(input[i]);
                }
                for (int i = inputNoSpace.Length-1; i >= 0; i--)
                {
                    reverse += inputNoSpace[i];
                }
                if (reverse == inputNoSpace)
                {
                    MessageBox.Show("São palíndromos");
                }
                else
                {
                    MessageBox.Show("Não são palíndromos");
                }
            }
        }


        private void frmExercicio3_Load(object sender, EventArgs e)
        {

        }
    }
}
