﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace ATIVIDADE5
{
    public partial class frmExercicio1 : Form
    {
        public frmExercicio1()
        {
            InitializeComponent();
        }

        private void label2_Click(object sender, EventArgs e)
        {

        }

        private void button1_Click(object sender, EventArgs e)
        {
            string input;
            int count=0;
            if (rchtxtFrase.Text.ToString() == "")
            {
                MessageBox.Show("Não foi escrita a frase.");
                rchtxtFrase.Focus();
            }
            else
            {
                input = rchtxtFrase.Text.ToString();
                for (int a = 0; a < input.Length; a++)
                {
                    if (char.IsWhiteSpace(input[a]))
                        count++;
                }
                MessageBox.Show($"Existem {count} espaços na frase.");
            }
        }

        private void btnR_Click(object sender, EventArgs e)
        {
            string input;
            int count=0;
            if (rchtxtFrase.Text.ToString() == "")
            {
                MessageBox.Show("Não foi escrita a frase.");
                rchtxtFrase.Focus();
            }
            else
            {
                input = rchtxtFrase.Text.ToString();
                foreach ( char c in input)
                {
                    if (char.ToLower(c) == 'r')
                        count++;
                }
                MessageBox.Show($"O número de vezes que aparece a letra R é {count}");
            }
        }

        private void btnParLetra_Click(object sender, EventArgs e)
        {
            string input;
            char a;
            int i=1, count = 0;
            if (rchtxtFrase.Text.ToString() == "")
            {
                MessageBox.Show("Não foi escrita a frase.");
                rchtxtFrase.Focus();
            }
            else
            {
                input = rchtxtFrase.Text.ToString();
               
                while (i<input.Length)
                {
                    a = input[i];
                    if (a == input[i - 1])
                    {
                        count++;
                    }
                    i++;
                }
                MessageBox.Show($"A quantidade de par de letras é {count}");
            }
        }
    }
}
