﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace ATIVIDADE5
{
    public partial class frmExercicio4 : Form
    {
        public frmExercicio4()
        {
            InitializeComponent();
        }

        private void frmExercicio4_Load(object sender, EventArgs e)
        {

        }

        private void btnCalc_Click(object sender, EventArgs e)
        {
            string Nome, Matric;
            int Prod=0;
            double Sal=0, Grat=0, SalBruto=0, B, C, D;
            if (string.IsNullOrEmpty(txtNome.Text))
            {
                MessageBox.Show("O campo nome está vazio.");
                txtNome.Focus();
            }
            else if (string.IsNullOrEmpty(txtMatricula.Text))
            {
                MessageBox.Show("O campo matrícula está vazio.");
                txtMatricula.Focus();
            }
            else if (!int.TryParse(txtProd.Text, out Prod))
            {
                MessageBox.Show("O campo produção está vazio ou não é um número inteiro.");
                txtProd.Focus();
            }
            else if (!double.TryParse(txtSal.Text, out Sal))
            {
                MessageBox.Show("O campo salário está vazio ou não é um número.");
                txtSal.Focus();
            }
            else if (!double.TryParse(txtGrat.Text, out Grat))
            {
                MessageBox.Show("O campo gratificação está vazio ou não é um número.");
                txtGrat.Focus();
            }
            else
            {
                B = C = D = 0;
                if (Prod >= 150)
                    B = C = D = 1;
                else if (Prod >= 120)
                    B = C = 1;
                else if (Prod >= 100)
                    B = 1;
                
                SalBruto = Sal + Sal * (0.05 * B + 0.1 * C + 0.1 * D) + Grat;
                if (SalBruto > 7000 && (Prod < 150 || Grat == 0))
                    SalBruto = 7000.00;
                MessageBox.Show($"O Salário Bruto é: {SalBruto:F2}");
            }
        }
    }
}
