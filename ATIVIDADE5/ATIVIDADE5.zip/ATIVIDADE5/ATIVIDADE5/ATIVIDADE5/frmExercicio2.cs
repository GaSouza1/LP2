﻿using System;
using System.Windows.Forms;

namespace ATIVIDADE5
{
    public partial class frmExercicio2 : Form
    {
        public frmExercicio2()
        {
            InitializeComponent();
        }

        private void label1_Click(object sender, EventArgs e)
        {

        }

        private void btnH_Click(object sender, EventArgs e)
        {
            double N = 0;
            double H = 0;
            if (!double.TryParse(txtN.Text, out N))
            {
                MessageBox.Show("Você não digitou um número.");
            }
            else if (N < 0)
            {
                MessageBox.Show("O número é menor que 0.");
            }
            else
            {
                for (int i = 1; i <= N; i++)
                {
                    H += (double)1 / i;
                }
                MessageBox.Show($"O número H é: {H:F2}");
            }
        }
    }
}
