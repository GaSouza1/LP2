﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Exercicios
{
    public partial class frmExercicio1 : Form
    {
        public frmExercicio1()
        {
            InitializeComponent();
        }

        private void btnExec_Click(object sender, EventArgs e)
        {
            DateTime nascimento = mnthIdade.SelectionRange.Start;
            TimeSpan diferenca = DateTime.Now - nascimento;
            int anos = (int)Math.Truncate(diferenca.TotalDays / 365);
            int mes = (int)Math.Truncate(diferenca.TotalDays % 365 / 12);
            int dia = (int)diferenca.TotalDays % 365 % 12;
            MessageBox.Show($"Você tem {anos} anos de idade.");
            if (nascimento.Month == DateTime.Now.Month && nascimento.Day == DateTime.Now.Day)
            {
                MessageBox.Show("Hoje é seu aniversário.");
            }
            else
            {
                MessageBox.Show("Hoje não é seu aniversário.");
            }

        }
    }
}
