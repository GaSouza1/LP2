﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Exercicios
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void btnEx1_Click(object sender, EventArgs e)
        {
            var frm = Application.OpenForms.OfType<frmExercicio1>().FirstOrDefault();
            if (frm != null)
            {
                if (frm.WindowState == FormWindowState.Minimized)
                {
                    frm.WindowState = FormWindowState.Normal;
                }
                frm.BringToFront();
                frm.Activate();
            }
            else
            {
                frmExercicio1 FrmExercicio1 = new frmExercicio1();
                FrmExercicio1.Show();
            }

        }

        private void btnEx2_Click(object sender, EventArgs e)
        {
            var frm = Application.OpenForms.OfType<frmExercicio2>().FirstOrDefault();
            if (frm != null)
            {
                if (frm.WindowState == FormWindowState.Minimized)
                {
                    frm.WindowState = FormWindowState.Normal;
                }
                frm.BringToFront();
                frm.Activate();
            }
            else
            {
                frmExercicio2 FrmExercicio2 = new frmExercicio2();
                FrmExercicio2.Show();
            }
        }
    }
}
