﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Exercicios
{
    public partial class frmExercicio2 : Form
    {
        public frmExercicio2()
        {
            InitializeComponent();
        }

        private void btnExec_Click(object sender, EventArgs e)
        {
            DateTime datenow = DateTime.Now;
            int minutos;
            if (!int.TryParse(txtMinutos.Text, out minutos))
            {
                MessageBox.Show("Entrada inválida.");
                txtMinutos.Focus();
                return;
            } 

        }
    }
}
