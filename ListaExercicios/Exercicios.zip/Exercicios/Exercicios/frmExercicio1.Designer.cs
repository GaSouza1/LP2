﻿namespace Exercicios
{
    partial class frmExercicio1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.mnthIdade = new System.Windows.Forms.MonthCalendar();
            this.btnExec = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // mnthIdade
            // 
            this.mnthIdade.Location = new System.Drawing.Point(148, 79);
            this.mnthIdade.Name = "mnthIdade";
            this.mnthIdade.TabIndex = 0;
            // 
            // btnExec
            // 
            this.btnExec.Location = new System.Drawing.Point(427, 148);
            this.btnExec.Name = "btnExec";
            this.btnExec.Size = new System.Drawing.Size(153, 93);
            this.btnExec.TabIndex = 1;
            this.btnExec.Text = "Calcular idade";
            this.btnExec.UseVisualStyleBackColor = true;
            this.btnExec.Click += new System.EventHandler(this.btnExec_Click);
            // 
            // frmExercicio1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(800, 450);
            this.Controls.Add(this.btnExec);
            this.Controls.Add(this.mnthIdade);
            this.Name = "frmExercicio1";
            this.Text = "frmExercicio1";
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.MonthCalendar mnthIdade;
        private System.Windows.Forms.Button btnExec;
    }
}