﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Ex6
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void Form1_Load(object sender, EventArgs e)
        {

        }

        private void cmbJogador_SelectedIndexChanged(object sender, EventArgs e)
        {
            string[] jogadas = { "Pedra", "Papel", "Tesoura" };
            Random computador = new Random();
            int jogadasComp = computador.Next(0, 3);
            txtMaquina.Text = jogadas[jogadasComp];
            if (jogadasComp == cmbJogador.SelectedIndex)
                MessageBox.Show("Empate.");
            else if (jogadasComp == 0 && cmbJogador.SelectedIndex == 1)
                MessageBox.Show("Papel vence Pedra, Jogador venceu.");
            else if (jogadasComp == 0 && cmbJogador.SelectedIndex == 2)
                MessageBox.Show("Pedra vence tesoura, Computador venceu.");
            else if (jogadasComp == 1 && cmbJogador.SelectedIndex == 0)
                MessageBox.Show("Papel vence Pedra, Computador venceu.");
            else if (jogadasComp == 1 && cmbJogador.SelectedIndex == 2)
                MessageBox.Show("Tesoura vence papel, Jogador venceu.");
            else if (jogadasComp == 2 && cmbJogador.SelectedIndex == 0)
                MessageBox.Show("Pedra vence tesoura, Jogador venceu.");
            else if (jogadasComp == 2 && cmbJogador.SelectedIndex == 1)
                MessageBox.Show("Tesoura vence papel, Computador venceu.");
        }
    }
}
