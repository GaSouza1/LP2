﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Ex4
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void comboBox2_SelectedIndexChanged(object sender, EventArgs e)
        {

        }

        private void Form1_Load(object sender, EventArgs e)
        {
            for (int i = 18; i <= 75; i++)
            {
                cmbIdade.Items.Add(i);
            }
            
        }

        private void groupBox1_Enter(object sender, EventArgs e)
        {

        }

        private void btnExec_Click(object sender, EventArgs e)
        {
            double n;
            msktxtSalario.TextMaskFormat = MaskFormat.ExcludePromptAndLiterals;
            if (txtNome.Text == "") {
                MessageBox.Show("Nome não preenchido.");
                txtNome.Focus();
                return;
            }

            else if (txtTelefone.Text == "")
            {
                MessageBox.Show("Telefone não preenchido.");
                txtTelefone.Focus();
                return;
            }
            else if (cmbIdade.SelectedIndex == -1)
            {
                MessageBox.Show("Idade não preenchida.");
                cmbIdade.Focus();
                return;
            }
            else if (!radioCasado.Checked && !radioSolteiro.Checked && !radioDivorc.Checked && !radioDesq.Checked && !radioOutro.Checked)
            {
                MessageBox.Show("Estado civil não preenchido.");
                return;
            }
            else if (!checkMasculino.Checked && !checkFeminino.Checked)
            {
                MessageBox.Show("Sexo não preenchido.");
                return;
            }
            else if (cmbMoradia.SelectedIndex == -1)
            {
                MessageBox.Show("Distância de moradia não preenchida.");
                cmbMoradia.Focus();
                return;
            }
            else if (txtAnterior.Text == "")
            {
                MessageBox.Show("Nome da empresa não preenchido.");
                txtAnterior.Focus();
                return;
            }
            else if (cmbExperiencia.SelectedIndex == -1)
            {
                MessageBox.Show("Tempo de experiência não preenchido.");
                cmbExperiencia.Focus();
                return;
            }
            else if (!double.TryParse(msktxtSalario.Text, out n))
            {
                MessageBox.Show("Salário Invalido");
                msktxtSalario.Focus();
                return;
            }

            if (cmbExperiencia.SelectedIndex == 0)
            {
                MessageBox.Show("Agradecemos pela participação, não contém requisitos necessários para preencher a vaga.");
            }
            else if (cmbMoradia.SelectedIndex == 3)
                MessageBox.Show("Não preenche os requisitos pois a empresa não fornece transporte.");
            else if (cmbExperiencia.SelectedIndex == 1)
                MessageBox.Show("Aguardar, será chamado para um teste.");
            else if (n/100 >= 1000.00 && n/100 <= 2500.00)
                MessageBox.Show("Contratado.");
            else
                MessageBox.Show("Não preenche os requisitos.");
        }
    }
}
