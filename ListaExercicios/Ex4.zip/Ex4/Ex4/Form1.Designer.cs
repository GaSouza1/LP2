﻿namespace Ex4
{
    partial class Form1
    {
        /// <summary>
        /// Variável de designer necessária.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Limpar os recursos que estão sendo usados.
        /// </summary>
        /// <param name="disposing">true se for necessário descartar os recursos gerenciados; caso contrário, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Código gerado pelo Windows Form Designer

        /// <summary>
        /// Método necessário para suporte ao Designer - não modifique 
        /// o conteúdo deste método com o editor de código.
        /// </summary>
        private void InitializeComponent()
        {
            this.txtNome = new System.Windows.Forms.TextBox();
            this.lbl1 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.txtTelefone = new System.Windows.Forms.TextBox();
            this.label3 = new System.Windows.Forms.Label();
            this.cmbIdade = new System.Windows.Forms.ComboBox();
            this.label4 = new System.Windows.Forms.Label();
            this.checkMasculino = new System.Windows.Forms.CheckBox();
            this.radioSolteiro = new System.Windows.Forms.RadioButton();
            this.label5 = new System.Windows.Forms.Label();
            this.label6 = new System.Windows.Forms.Label();
            this.txtAnterior = new System.Windows.Forms.TextBox();
            this.cmbExperiencia = new System.Windows.Forms.ComboBox();
            this.label7 = new System.Windows.Forms.Label();
            this.label8 = new System.Windows.Forms.Label();
            this.msktxtSalario = new System.Windows.Forms.MaskedTextBox();
            this.btnExec = new System.Windows.Forms.Button();
            this.checkFeminino = new System.Windows.Forms.CheckBox();
            this.radioCasado = new System.Windows.Forms.RadioButton();
            this.radioDesq = new System.Windows.Forms.RadioButton();
            this.radioDivorc = new System.Windows.Forms.RadioButton();
            this.radioOutro = new System.Windows.Forms.RadioButton();
            this.label1 = new System.Windows.Forms.Label();
            this.cmbMoradia = new System.Windows.Forms.ComboBox();
            this.SuspendLayout();
            // 
            // txtNome
            // 
            this.txtNome.Location = new System.Drawing.Point(130, 38);
            this.txtNome.Name = "txtNome";
            this.txtNome.Size = new System.Drawing.Size(100, 20);
            this.txtNome.TabIndex = 0;
            // 
            // lbl1
            // 
            this.lbl1.AutoSize = true;
            this.lbl1.Location = new System.Drawing.Point(33, 38);
            this.lbl1.Name = "lbl1";
            this.lbl1.Size = new System.Drawing.Size(35, 13);
            this.lbl1.TabIndex = 1;
            this.lbl1.Text = "Nome";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(33, 92);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(49, 13);
            this.label2.TabIndex = 3;
            this.label2.Text = "Telefone";
            // 
            // txtTelefone
            // 
            this.txtTelefone.Location = new System.Drawing.Point(130, 92);
            this.txtTelefone.Name = "txtTelefone";
            this.txtTelefone.Size = new System.Drawing.Size(100, 20);
            this.txtTelefone.TabIndex = 2;
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(33, 156);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(34, 13);
            this.label3.TabIndex = 4;
            this.label3.Text = "Idade";
            // 
            // cmbIdade
            // 
            this.cmbIdade.FormattingEnabled = true;
            this.cmbIdade.Location = new System.Drawing.Point(130, 153);
            this.cmbIdade.Name = "cmbIdade";
            this.cmbIdade.Size = new System.Drawing.Size(121, 21);
            this.cmbIdade.TabIndex = 5;
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Location = new System.Drawing.Point(33, 284);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(31, 13);
            this.label4.TabIndex = 6;
            this.label4.Text = "Sexo";
            // 
            // checkMasculino
            // 
            this.checkMasculino.AutoSize = true;
            this.checkMasculino.Checked = true;
            this.checkMasculino.CheckState = System.Windows.Forms.CheckState.Checked;
            this.checkMasculino.Location = new System.Drawing.Point(130, 284);
            this.checkMasculino.Name = "checkMasculino";
            this.checkMasculino.Size = new System.Drawing.Size(74, 17);
            this.checkMasculino.TabIndex = 7;
            this.checkMasculino.Text = "Masculino";
            this.checkMasculino.UseVisualStyleBackColor = true;
            // 
            // radioSolteiro
            // 
            this.radioSolteiro.AutoSize = true;
            this.radioSolteiro.Location = new System.Drawing.Point(130, 212);
            this.radioSolteiro.Name = "radioSolteiro";
            this.radioSolteiro.Size = new System.Drawing.Size(60, 17);
            this.radioSolteiro.TabIndex = 8;
            this.radioSolteiro.TabStop = true;
            this.radioSolteiro.Text = "Solteiro";
            this.radioSolteiro.UseVisualStyleBackColor = true;
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Location = new System.Drawing.Point(33, 216);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(62, 13);
            this.label5.TabIndex = 9;
            this.label5.Text = "Estado Civil";
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Location = new System.Drawing.Point(305, 38);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(228, 13);
            this.label6.TabIndex = 11;
            this.label6.Text = "Nome da empresa one trabalhou anteriormente";
            // 
            // txtAnterior
            // 
            this.txtAnterior.Location = new System.Drawing.Point(543, 38);
            this.txtAnterior.Name = "txtAnterior";
            this.txtAnterior.Size = new System.Drawing.Size(100, 20);
            this.txtAnterior.TabIndex = 10;
            // 
            // cmbExperiencia
            // 
            this.cmbExperiencia.FormattingEnabled = true;
            this.cmbExperiencia.Items.AddRange(new object[] {
            "até um ano",
            "de um a dois anos",
            "de dois a três anos",
            "mais do que cinco anos"});
            this.cmbExperiencia.Location = new System.Drawing.Point(437, 84);
            this.cmbExperiencia.Name = "cmbExperiencia";
            this.cmbExperiencia.Size = new System.Drawing.Size(121, 21);
            this.cmbExperiencia.TabIndex = 13;
            this.cmbExperiencia.SelectedIndexChanged += new System.EventHandler(this.comboBox2_SelectedIndexChanged);
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.Location = new System.Drawing.Point(305, 92);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(113, 13);
            this.label7.TabIndex = 12;
            this.label7.Text = "Tempo de Experiência";
            // 
            // label8
            // 
            this.label8.AutoSize = true;
            this.label8.Location = new System.Drawing.Point(305, 141);
            this.label8.Name = "label8";
            this.label8.Size = new System.Drawing.Size(92, 13);
            this.label8.TabIndex = 14;
            this.label8.Text = "Salário pretendido";
            // 
            // msktxtSalario
            // 
            this.msktxtSalario.Location = new System.Drawing.Point(437, 134);
            this.msktxtSalario.Mask = "$ 9999,99";
            this.msktxtSalario.Name = "msktxtSalario";
            this.msktxtSalario.Size = new System.Drawing.Size(100, 20);
            this.msktxtSalario.TabIndex = 15;
            // 
            // btnExec
            // 
            this.btnExec.Location = new System.Drawing.Point(437, 216);
            this.btnExec.Name = "btnExec";
            this.btnExec.Size = new System.Drawing.Size(192, 85);
            this.btnExec.TabIndex = 16;
            this.btnExec.Text = "Candidatar";
            this.btnExec.UseVisualStyleBackColor = true;
            this.btnExec.Click += new System.EventHandler(this.btnExec_Click);
            // 
            // checkFeminino
            // 
            this.checkFeminino.AutoSize = true;
            this.checkFeminino.Location = new System.Drawing.Point(210, 283);
            this.checkFeminino.Name = "checkFeminino";
            this.checkFeminino.Size = new System.Drawing.Size(68, 17);
            this.checkFeminino.TabIndex = 17;
            this.checkFeminino.Text = "Feminino";
            this.checkFeminino.UseVisualStyleBackColor = true;
            // 
            // radioCasado
            // 
            this.radioCasado.AutoSize = true;
            this.radioCasado.Location = new System.Drawing.Point(191, 212);
            this.radioCasado.Name = "radioCasado";
            this.radioCasado.Size = new System.Drawing.Size(61, 17);
            this.radioCasado.TabIndex = 18;
            this.radioCasado.TabStop = true;
            this.radioCasado.Text = "Casado";
            this.radioCasado.UseVisualStyleBackColor = true;
            // 
            // radioDesq
            // 
            this.radioDesq.AutoSize = true;
            this.radioDesq.Location = new System.Drawing.Point(258, 212);
            this.radioDesq.Name = "radioDesq";
            this.radioDesq.Size = new System.Drawing.Size(79, 17);
            this.radioDesq.TabIndex = 19;
            this.radioDesq.TabStop = true;
            this.radioDesq.Text = "Desquitado";
            this.radioDesq.UseVisualStyleBackColor = true;
            // 
            // radioDivorc
            // 
            this.radioDivorc.AutoSize = true;
            this.radioDivorc.Location = new System.Drawing.Point(130, 235);
            this.radioDivorc.Name = "radioDivorc";
            this.radioDivorc.Size = new System.Drawing.Size(76, 17);
            this.radioDivorc.TabIndex = 20;
            this.radioDivorc.TabStop = true;
            this.radioDivorc.Text = "Divorciado";
            this.radioDivorc.UseVisualStyleBackColor = true;
            // 
            // radioOutro
            // 
            this.radioOutro.AutoSize = true;
            this.radioOutro.Location = new System.Drawing.Point(258, 235);
            this.radioOutro.Name = "radioOutro";
            this.radioOutro.Size = new System.Drawing.Size(56, 17);
            this.radioOutro.TabIndex = 21;
            this.radioOutro.TabStop = true;
            this.radioOutro.Text = "Outros";
            this.radioOutro.UseVisualStyleBackColor = true;
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(33, 333);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(170, 13);
            this.label1.TabIndex = 22;
            this.label1.Text = "Distância entre empresa e moraida";
            // 
            // cmbMoradia
            // 
            this.cmbMoradia.FormattingEnabled = true;
            this.cmbMoradia.Items.AddRange(new object[] {
            "de 0 até 20 KM",
            "de 21 até 50 KM",
            "de 51 a 100 KM",
            "maior que 100 KM"});
            this.cmbMoradia.Location = new System.Drawing.Point(216, 333);
            this.cmbMoradia.Name = "cmbMoradia";
            this.cmbMoradia.Size = new System.Drawing.Size(121, 21);
            this.cmbMoradia.TabIndex = 23;
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(800, 450);
            this.Controls.Add(this.cmbMoradia);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.radioOutro);
            this.Controls.Add(this.radioDivorc);
            this.Controls.Add(this.radioDesq);
            this.Controls.Add(this.radioCasado);
            this.Controls.Add(this.checkFeminino);
            this.Controls.Add(this.btnExec);
            this.Controls.Add(this.msktxtSalario);
            this.Controls.Add(this.label8);
            this.Controls.Add(this.cmbExperiencia);
            this.Controls.Add(this.label7);
            this.Controls.Add(this.label6);
            this.Controls.Add(this.txtAnterior);
            this.Controls.Add(this.label5);
            this.Controls.Add(this.radioSolteiro);
            this.Controls.Add(this.checkMasculino);
            this.Controls.Add(this.label4);
            this.Controls.Add(this.cmbIdade);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.txtTelefone);
            this.Controls.Add(this.lbl1);
            this.Controls.Add(this.txtNome);
            this.Name = "Form1";
            this.Text = "Form1";
            this.Load += new System.EventHandler(this.Form1_Load);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.TextBox txtNome;
        private System.Windows.Forms.Label lbl1;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.TextBox txtTelefone;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.ComboBox cmbIdade;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.CheckBox checkMasculino;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.TextBox txtAnterior;
        private System.Windows.Forms.ComboBox cmbExperiencia;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.Label label8;
        private System.Windows.Forms.MaskedTextBox msktxtSalario;
        private System.Windows.Forms.Button btnExec;
        private System.Windows.Forms.RadioButton radioSolteiro;
        private System.Windows.Forms.CheckBox checkFeminino;
        private System.Windows.Forms.RadioButton radioCasado;
        private System.Windows.Forms.RadioButton radioDesq;
        private System.Windows.Forms.RadioButton radioDivorc;
        private System.Windows.Forms.RadioButton radioOutro;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.ComboBox cmbMoradia;
    }
}

