﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using Microsoft.VisualBasic;

namespace PConsumo
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void btnExec_Click(object sender, EventArgs e)
        {
            double[,] Consumo = new double[5, 4];
            double[] somaConsumo = new double[5];
            double totalGeral = 0;
            string[] Setores = { "Produção", "Escritório", "Refeitório", "Limpeza", "Logística" };
            string aux;
            for (int setor = 0; setor < Consumo.GetLength(0); setor++) {
                for (int semana = 0; semana < Consumo.GetLength(1); semana++) {
                    aux = Interaction.InputBox($"Digite o consumo do(a) {Setores[setor]} na {semana + 1} semana.", "Entrada de dados");
                    if (!double.TryParse(aux, out Consumo[setor, semana]) || Consumo[setor, semana] < 0)
                    {
                        MessageBox.Show("Valor inválido.");
                    }
                    else
                    {
                        somaConsumo[setor] += Consumo[setor, semana];
                        totalGeral += Consumo[setor, semana];
                    }
                }
            }
            for (int setor = 0; setor < 5; setor++)
            {
                lstbxConsumo.Items.Add($"{Setores[setor]}: {somaConsumo[setor]} L -> {somaConsumo[setor] * 0.01:C2}");
            }
            lstbxConsumo.Items.Add("-------------------------------------");
            lstbxConsumo.Items.Add($"Total Geral: {totalGeral} L -> {totalGeral * 0.01:C2}");
        }

        private void btnLimpar_Click(object sender, EventArgs e)
        {
            lstbxConsumo.Items.Clear();
        }
    }
}
