﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Ex5
{
    public partial class Form1 : Form
    {
        double[] medidas = { 15.0, 0.4535923, 28.349, 0.4046856224, 10000.0, 4.84, 2.42, 2.72, 1.8288, 0.9144, 30.48, 2.54, 1.609344};

        public Form1()
        {
            InitializeComponent();
        }

        private void Form1_Load(object sender, EventArgs e)
        {

        }

        private void comboBox1_SelectedIndexChanged(object sender, EventArgs e)
        {
            txtDe.Clear();
            txtPara.Clear();
            txtDe.Focus();
        }

        private void txtDe_Validated(object sender, EventArgs e)
        {
         
        }

        private void txtDe_PreviewKeyDown(object sender, PreviewKeyDownEventArgs e)
        {

        }

        private void txtDe_KeyDown(object sender, KeyEventArgs e)
        {
            double n;
            if (e.KeyCode == Keys.Enter)
            {
                if (cmbMedidas.SelectedIndex == -1)
                    MessageBox.Show("Medida não selecionada.");
                else if (!double.TryParse(txtDe.Text, out n))
                    MessageBox.Show("Valor invalido.");
                else
                {
                    double fator = medidas[cmbMedidas.SelectedIndex];
                    txtPara.Text = (n*fator).ToString();
                }
            }   
        }

        private void txtPara_KeyDown(object sender, KeyEventArgs e)
        {
            double n;
            if (e.KeyCode == Keys.Enter)
            {
                if (cmbMedidas.SelectedIndex == -1)
                    MessageBox.Show("Medida não selecionada.");
                else if (!double.TryParse(txtPara.Text, out n))
                    MessageBox.Show("Valor invalido.");
                else
                {
                    double fator = medidas[cmbMedidas.SelectedIndex];
                    txtDe.Text = (n / fator).ToString();
                }
            }
        }
    }
}
